package problems;

public class Main {
   public static void main(String[] args) {
      FloorCeilBinarySearch f = new FloorCeilBinarySearch();
      Integer[] array = { 1, 2, 4, 5, 6, 7, 9, 10, 23 };
      System.out.println(f.floor(array, 5));
      System.out.println(f.ceil(array, 22));
   }
}
