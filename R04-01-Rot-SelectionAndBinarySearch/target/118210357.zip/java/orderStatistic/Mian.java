package orderStatistic;

public class Mian {
    public static void main(String[] args) {
        Integer[] array = {6, 8, 3, 3, 5, 9};
        OrderStatisticsSelectionImpl a = new OrderStatisticsSelectionImpl();
        System.out.println(a.getOrderStatistics(array, 9));
    }
}
